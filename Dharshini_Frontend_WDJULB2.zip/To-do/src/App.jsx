import React, { useState } from 'react';
import TodoList from './TodoList';
import TodoForm from './TodoForm';
import Tabs from './Tabs';
import './App.css';

function App() {
  const [todos, setTodos] = useState([]); 
  const [activeTab, setActiveTab] = useState('todo'); 

  // Function to add a new todo
  const handleAddTodo = (title, description) => {
    const newTodo = { id: Date.now(), title, description, completed: false }; 
    setTodos([...todos, newTodo]);
  };

  // Function to toggle completion status 
  const toggleComplete = (id) => {
    setTodos(todos.map(todo => (
      todo.id === id ? { ...todo, completed: !todo.completed } : todo
    )));
  };

  // Function to delete 
  const deleteTodo = (id) => {
    setTodos(todos.filter(todo => todo.id !== id)); 
  };

  // Function to edit a todo 
  const editTodo = (id, newTitle, newDescription) => {
    setTodos(todos.map(todo => (
      todo.id === id ? { ...todo, title: newTitle, description: newDescription } : todo
    )));
  };

  

  return (
    <div className="container">
      <h1>My Todos</h1>
      <TodoForm handleAddTodo={handleAddTodo} />

     
      <Tabs activeTab={activeTab} setActiveTab={setActiveTab} />

     
      <TodoList
        todos={todos.filter(todo => (
          activeTab === 'todo' ? !todo.completed : todo.completed
        ))}
        toggleComplete={toggleComplete}
        deleteTodo={deleteTodo}
        editTodo={editTodo} 
      />
    </div>
  );
}

export default App;
