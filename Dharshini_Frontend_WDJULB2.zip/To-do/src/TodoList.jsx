import React from 'react';
import TodoItem from './TodoItem';

function TodoList({ todos, toggleComplete, deleteTodo, editTodo }) {
  return (
    <ul className="list">
      {todos.length === 0 && <li>No items here....!</li>}
      {todos.map((todo) => (
        <TodoItem
          key={todo.id} 
          todo={todo}
          toggleComplete={toggleComplete}
          deleteTodo={deleteTodo}
          editTodo={editTodo} 
        />
      ))}
    </ul>
  );
}

export default TodoList;
