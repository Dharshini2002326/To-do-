import React, { useState } from 'react';

function TodoForm({ handleAddTodo }) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (title && description) {
      handleAddTodo(title, description);
      setTitle('');
      setDescription('');
    } else {
      alert('Please enter both title and description.');
    }
  };

  return (
    <form className="form" onSubmit={handleSubmit}>
      <div className="input-group">
        <label htmlFor="title">Title:</label>
        <input
          id="title"
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="What's the title of your To Do?"
        />
      </div>
      <div className="input-group">
        <label htmlFor="description">Description:</label>
        <input
          id="description"
          type="text"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="What's the description of your To Do?"
        />
      </div>
      <button className="add-button" type="submit">ADD</button>
    </form>
  );
}

export default TodoForm;
