import React from 'react';

function Tabs({ activeTab, setActiveTab }) {
  return (
    <div className="tabs">
      <button
        className={`tab ${activeTab === 'todo' ? 'active' : ''}`}
        onClick={() => setActiveTab('todo')}
      >
        To Do
      </button>
      <button
        className={`tab ${activeTab === 'completed' ? 'active' : ''}`}
        onClick={() => setActiveTab('completed')}
      >
        Completed
      </button>
    </div>
  );
}

export default Tabs;
