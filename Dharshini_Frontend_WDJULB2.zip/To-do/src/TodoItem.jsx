import React, { useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEdit, faTrash } from '@fortawesome/free-solid-svg-icons';

function TodoItem({ todo, toggleComplete, deleteTodo, editTodo }) {
  const [isEditing, setIsEditing] = useState(false);
  const [newTitle, setNewTitle] = useState(todo.title);
  const [newDescription, setNewDescription] = useState(todo.description);

  const handleSave = () => {
    if (newTitle.trim() && newDescription.trim()) {
      editTodo(todo.id, newTitle, newDescription);
      setIsEditing(false);
    } else {
      alert('Please fill both fields!');
    }
  };

  return (
    <li className="todo-item">
      {isEditing ? (
        <div className="edit-mode">
          <input
            type="text"
            value={newTitle}
            onChange={(e) => setNewTitle(e.target.value)}
          />
          <input
            type="text"
            value={newDescription}
            onChange={(e) => setNewDescription(e.target.value)}
          />
          <button onClick={handleSave}>Save</button>
        </div>
      ) : (
        <>
          <span
            className={`todo-text ${todo.completed ? 'completed' : ''}`}
            onClick={() => toggleComplete(todo.id)}
          >
            {todo.title} - {todo.description}
          </span>
          <div id="buttons1">
          <button onClick={() => setIsEditing(true)} style={{ backgroundColor: 'transparent', border: 'none' }}>
  <FontAwesomeIcon icon={faEdit} style={{ color: 'pink' }} />
</button>

<button className="delete-btn" onClick={() => deleteTodo(todo.id)} style={{ backgroundColor: 'transparent', border: 'none' }}>
  <FontAwesomeIcon icon={faTrash} style={{ color: 'red' }} />
</button>

          </div>
        </>
      )}
    </li>
  );
}

export default TodoItem;
